# NoteFlow

A mobile-first, local-first notes app built with React + TypeScript + Vite + Tiptap.

## Run locally

Requirements:
- Node.js 18+ (Node 20+ recommended)
- npm

```bash
npm install
npm run dev
```

Then open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

## Included

- Rich text editor
- Autosave to localStorage
- Search
- Folders
- Tags
- Pinned notes
- Favorites
- Archive
- Trash + restore
- Dark/light/system theme
- Import/export JSON
- TXT/Markdown export
- Responsive mobile/desktop UI
- Student-oriented AI integration placeholder
- Onboarding

## Privacy

The first version is local-first. Notes are stored in the browser and are not uploaded to a server.

## AI

The AI UI is intentionally not fake. A service abstraction can be connected to an API/backend later.
