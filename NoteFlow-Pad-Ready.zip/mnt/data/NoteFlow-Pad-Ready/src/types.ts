export type NoteColor = "default" | "red" | "orange" | "yellow" | "green" | "blue" | "purple";
export type View = "home" | "search" | "favorites" | "archive" | "trash" | "folders" | "settings";

export interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
  folderId: string | null;
  tags: string[];
  isPinned: boolean;
  isFavorite: boolean;
  isArchived: boolean;
  isTrashed: boolean;
  color: NoteColor;
}

export interface Folder {
  id: string;
  name: string;
  createdAt: number;
}

export interface Settings {
  theme: "light" | "dark" | "system";
  fontSize: "small" | "medium" | "large";
  lineSpacing: "compact" | "comfortable" | "relaxed";
  autosave: boolean;
}