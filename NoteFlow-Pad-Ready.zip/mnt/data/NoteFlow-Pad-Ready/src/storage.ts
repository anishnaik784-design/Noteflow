import type { Folder, Note, Settings } from "./types";

const KEY = "noteflow-data-v1";

interface Store {
  notes: Note[];
  folders: Folder[];
  settings: Settings;
  onboarded: boolean;
}

const defaults: Store = {
  notes: [],
  folders: [
    { id: "school", name: "School", createdAt: Date.now() },
    { id: "personal", name: "Personal", createdAt: Date.now() },
    { id: "projects", name: "Projects", createdAt: Date.now() }
  ],
  settings: { theme: "system", fontSize: "medium", lineSpacing: "comfortable", autosave: true },
  onboarded: false
};

export function loadStore(): Store {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw);
    return {
      ...defaults,
      ...parsed,
      settings: { ...defaults.settings, ...(parsed.settings || {}) },
      folders: Array.isArray(parsed.folders) ? parsed.folders : defaults.folders,
      notes: Array.isArray(parsed.notes) ? parsed.notes : []
    };
  } catch {
    return defaults;
  }
}

export function saveStore(store: Store) {
  try { localStorage.setItem(KEY, JSON.stringify(store)); } catch { /* graceful degradation */ }
}