import { useEffect, useMemo, useState } from "react";
import {
  Archive, ArchiveRestore, Bold, Check, ChevronLeft, ChevronRight, CircleHelp,
  Clock3, Code2, Copy, Download, Edit3, Ellipsis, FileDown, FileText, Folder,
  FolderPlus, Heart, Home, Italic, List, ListChecks, ListOrdered, Menu, Moon,
  MoreHorizontal, Palette, Plus, Redo2, RotateCcw, Search, Settings, Sparkles,
  Star, Sun, Tag, Trash2, Undo2, Underline, Upload, X, Zap
} from "lucide-react";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import UnderlineExtension from "@tiptap/extension-underline";
import Highlight from "@tiptap/extension-highlight";
import Link from "@tiptap/extension-link";
import TextAlign from "@tiptap/extension-text-align";
import Placeholder from "@tiptap/extension-placeholder";
import type { Folder as FolderType, Note, NoteColor, Settings as SettingsType, View } from "./types";
import { loadStore, saveStore } from "./storage";

const uid = () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2)}`;

function stripHtml(html: string) {
  const div = document.createElement("div");
  div.innerHTML = html;
  return div.textContent || "";
}
function fmtTime(ts: number) {
  const d = new Date(ts), now = new Date();
  const same = d.toDateString() === now.toDateString();
  return same ? d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) : d.toLocaleDateString([], { month: "short", day: "numeric" });
}
function newNote(folderId: string | null = null): Note {
  const now = Date.now();
  return { id: uid(), title: "", content: "", createdAt: now, updatedAt: now, folderId, tags: [], isPinned: false, isFavorite: false, isArchived: false, isTrashed: false, color: "default" };
}

function Toolbar({ editor }: { editor: any }) {
  if (!editor) return null;
  const btn = (active: boolean, fn: () => void, label: string, icon: React.ReactNode) =>
    <button className={`tool ${active ? "active" : ""}`} onMouseDown={e => { e.preventDefault(); fn(); }} aria-label={label}>{icon}</button>;
  return <div className="toolbar">
    {btn(editor.isActive("bold"), () => editor.chain().focus().toggleBold().run(), "Bold", <Bold size={17}/>)}
    {btn(editor.isActive("italic"), () => editor.chain().focus().toggleItalic().run(), "Italic", <Italic size={17}/>)}
    {btn(editor.isActive("underline"), () => editor.chain().focus().toggleUnderline().run(), "Underline", <Underline size={17}/>)}
    {btn(editor.isActive("highlight"), () => editor.chain().focus().toggleHighlight().run(), "Highlight", <Palette size={17}/>)}
    <span className="tool-divider"/>
    <button className="tool select-tool" onMouseDown={e=>e.preventDefault()} onClick={()=>editor.chain().focus().toggleHeading({level:2}).run()}>H</button>
    {btn(editor.isActive("bulletList"), () => editor.chain().focus().toggleBulletList().run(), "Bullets", <List size={17}/>)}
    {btn(editor.isActive("orderedList"), () => editor.chain().focus().toggleOrderedList().run(), "Numbered list", <ListOrdered size={17}/>)}
    {btn(editor.isActive("taskList"), () => editor.chain().focus().toggleTaskList().run(), "Checklist", <ListChecks size={17}/>)} 
    {btn(editor.isActive("blockquote"), () => editor.chain().focus().toggleBlockquote().run(), "Quote", <span className="quote-icon">"</span>)}
    {btn(editor.isActive("codeBlock"), () => editor.chain().focus().toggleCodeBlock().run(), "Code", <Code2 size={17}/>)}
    <span className="tool-divider"/>
    {btn(false, () => editor.chain().focus().undo().run(), "Undo", <Undo2 size={17}/>)} 
    {btn(false, () => editor.chain().focus().redo().run(), "Redo", <Redo2 size={17}/>)} 
  </div>;
}

function App() {
  const initial = loadStore();
  const [notes, setNotes] = useState<Note[]>(initial.notes);
  const [folders, setFolders] = useState<FolderType[]>(initial.folders);
  const [settings, setSettings] = useState<SettingsType>(initial.settings);
  const [onboarded, setOnboarded] = useState(initial.onboarded);
  const [view, setView] = useState<View>("home");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [activeFolder, setActiveFolder] = useState<string | null>(null);
  const [activeTag, setActiveTag] = useState<string | null>(null);
  const [sidebar, setSidebar] = useState(false);
  const [folderModal, setFolderModal] = useState(false);
  const [tagModal, setTagModal] = useState(false);
  const [toast, setToast] = useState("");
  const [searches, setSearches] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => saveStore({ notes, folders, settings, onboarded }), [notes, folders, settings, onboarded]);
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme === "system" ? (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light") : settings.theme;
  }, [settings.theme]);

  const activeNote = notes.find(n => n.id === selectedId) ?? null;

  const visibleNotes = useMemo(() => {
    let result = notes.filter(n => view === "trash" ? n.isTrashed : !n.isTrashed);
    if (view === "archive") result = result.filter(n => n.isArchived);
    else if (view === "favorites") result = result.filter(n => n.isFavorite && !n.isArchived);
    else result = result.filter(n => !n.isArchived);
    if (activeFolder) result = result.filter(n => n.folderId === activeFolder);
    if (activeTag) result = result.filter(n => n.tags.includes(activeTag));
    const q = query.trim().toLowerCase();
    if (q) result = result.filter(n => `${n.title} ${stripHtml(n.content)} ${n.tags.join(" ")}`.toLowerCase().includes(q));
    return [...result].sort((a,b) => Number(b.isPinned)-Number(a.isPinned) || b.updatedAt-a.updatedAt);
  }, [notes, view, activeFolder, activeTag, query]);

  const updateNote = (id: string, patch: Partial<Note>) => {
    setSaving(true);
    setNotes(prev => prev.map(n => n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n));
    window.setTimeout(() => setSaving(false), 350);
  };

  const create = () => {
    const n = newNote(activeFolder);
    setNotes(prev => [n, ...prev]);
    setSelectedId(n.id);
    setView("home");
    setSidebar(false);
  };

  const notify = (msg: string) => { setToast(msg); window.setTimeout(() => setToast(""), 1800); };

  const remove = (id: string) => updateNote(id, { isTrashed: true, isArchived: false });
  const restore = (id: string) => updateNote(id, { isTrashed: false });
  const permanentlyDelete = (id: string) => setNotes(prev => prev.filter(n => n.id !== id));

  const exportNote = (n: Note, format: "txt"|"md"|"json") => {
    const text = format === "json" ? JSON.stringify(n, null, 2) : format === "md" ? `# ${n.title}\n\n${stripHtml(n.content)}` : `${n.title}\n\n${stripHtml(n.content)}`;
    const blob = new Blob([text], { type: format === "json" ? "application/json" : "text/plain" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `${n.title || "note"}.${format}`; a.click(); URL.revokeObjectURL(a.href);
    notify(`Exported as ${format.toUpperCase()}`);
  };

  const allTags = Array.from(new Set(notes.flatMap(n => n.tags))).sort();

  if (!onboarded) return <Onboarding onDone={() => setOnboarded(true)} />;

  return <div className={`app-shell ${activeNote ? "has-editor" : ""}`}>
    <aside className={`sidebar ${sidebar ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Zap size={18}/></div><span>NoteFlow</span><button className="mobile-close" onClick={()=>setSidebar(false)}><X size={19}/></button></div>
      <button className="new-btn" onClick={create}><Plus size={19}/> New note <span className="kbd">N</span></button>
      <nav>
        <NavItem icon={<Home size={18}/>} label="Home" active={view==="home" && !activeFolder} onClick={()=>{setView("home");setActiveFolder(null);setActiveTag(null);setSidebar(false)}}/>
        <NavItem icon={<Search size={18}/>} label="Search" active={view==="search"} onClick={()=>{setView("search");setSidebar(false)}}/>
        <NavItem icon={<Star size={18}/>} label="Favorites" active={view==="favorites"} onClick={()=>{setView("favorites");setSidebar(false)}}/>
        <NavItem icon={<Archive size={18}/>} label="Archive" active={view==="archive"} onClick={()=>{setView("archive");setSidebar(false)}}/>
        <NavItem icon={<Trash2 size={18}/>} label="Trash" active={view==="trash"} onClick={()=>{setView("trash");setSidebar(false)}}/>
      </nav>
      <div className="side-heading"><span>Folders</span><button onClick={()=>setFolderModal(true)} aria-label="Add folder"><Plus size={16}/></button></div>
      <div className="folder-list">
        {folders.map(f=><button key={f.id} className={`side-row ${activeFolder===f.id ? "selected":""}`} onClick={()=>{setActiveFolder(f.id);setActiveTag(null);setView("folders");setSidebar(false)}}><Folder size={16}/><span>{f.name}</span><small>{notes.filter(n=>n.folderId===f.id&&!n.isTrashed).length}</small></button>)}
      </div>
      <div className="side-heading"><span>Tags</span><button onClick={()=>setTagModal(true)} aria-label="Add tag"><Plus size={16}/></button></div>
      <div className="tag-cloud">{allTags.slice(0,8).map(t=><button key={t} className={`tag-pill ${activeTag===t?"selected":""}`} onClick={()=>{setActiveTag(t);setActiveFolder(null);setView("home");setSidebar(false)}}>#{t}</button>)}</div>
      <div className="sidebar-bottom"><NavItem icon={<Settings size={18}/>} label="Settings" active={view==="settings"} onClick={()=>{setView("settings");setSidebar(false)}}/></div>
    </aside>

    <main className="main">
      <header className="topbar">
        <button className="icon-btn mobile-menu" onClick={()=>setSidebar(true)}><Menu size={21}/></button>
        <div className="mobile-brand"><div className="brand-mark"><Zap size={16}/></div> NoteFlow</div>
        <div className="top-search"><Search size={17}/><input value={query} onChange={e=>{setQuery(e.target.value); if(e.target.value) setView("search")}} placeholder="Search notes..." /><kbd>⌘ K</kbd></div>
        <button className="icon-btn" onClick={()=>setSettings(s=>({...s,theme:s.theme==="dark"?"light":"dark"}))}>{settings.theme==="dark"?<Sun size={19}/>:<Moon size={19}/>}</button>
        <button className="avatar" onClick={()=>setView("settings")}>A</button>
      </header>

      <div className="content">
        {view==="settings" ? <SettingsView settings={settings} setSettings={setSettings} notes={notes} folders={folders} onImport={(imported)=>setNotes(p=>[...p,...imported])} /> :
         activeNote ? <Editor note={activeNote} folders={folders} saving={saving} update={updateNote} onBack={()=>setSelectedId(null)} onDelete={()=>{remove(activeNote.id);setSelectedId(null)}} onExport={exportNote} notify={notify}/> :
         <Dashboard
           view={view} notes={visibleNotes} folders={folders} tags={allTags} query={query} activeFolder={activeFolder}
           onOpen={setSelectedId} onCreate={create} onSearch={(q)=>{setQuery(q);setView("search")}}
           onUpdate={updateNote} onDelete={remove} onRestore={restore} onPermanentDelete={permanentlyDelete}
           onExport={exportNote} setFolderModal={setFolderModal}
         />}
      </div>
      {toast && <div className="toast"><Check size={16}/>{toast}</div>}
    </main>

    <nav className="mobile-nav">
      <button onClick={()=>{setView("home");setActiveFolder(null);setSelectedId(null)}} className={view==="home"?"active":""}><Home/><span>Home</span></button>
      <button onClick={()=>setView("search")} className={view==="search"?"active":""}><Search/><span>Search</span></button>
      <button onClick={create} className="mobile-add"><Plus/></button>
      <button onClick={()=>setView("favorites")} className={view==="favorites"?"active":""}><Star/><span>Favorites</span></button>
      <button onClick={()=>setView("settings")} className={view==="settings"?"active":""}><Settings/><span>Settings</span></button>
    </nav>

    {folderModal && <Modal title="New folder" onClose={()=>setFolderModal(false)}><FolderForm onCreate={name=>{setFolders(p=>[...p,{id:uid(),name,createdAt:Date.now()}]);setFolderModal(false);notify("Folder created")}}/></Modal>}
    {tagModal && <Modal title="Add a tag" onClose={()=>setTagModal(false)}><TagForm notes={notes} onCreate={tag=>{setNotes(p=>p.map(n=>n.id===selectedId?{...n,tags:Array.from(new Set([...n.tags,tag])),updatedAt:Date.now()}:n));setTagModal(false);notify("Tag added")}}/></Modal>}
  </div>;
}

function NavItem({icon,label,active,onClick}:{icon:React.ReactNode;label:string;active:boolean;onClick:()=>void}) {
  return <button className={`nav-item ${active?"active":""}`} onClick={onClick}>{icon}<span>{label}</span></button>;
}

function Dashboard({view,notes,folders,tags,query,activeFolder,onOpen,onCreate,onSearch,onUpdate,onDelete,onRestore,onPermanentDelete,onExport,setFolderModal}:any) {
  const title = view==="search" ? "Search" : view==="favorites" ? "Favorites" : view==="archive" ? "Archive" : view==="trash" ? "Trash" : activeFolder ? folders.find((f:any)=>f.id===activeFolder)?.name : "Your notes";
  const subtitle = view==="trash" ? "Notes waiting to be restored or removed." : view==="archive" ? "Keep completed notes out of your main feed." : "Capture ideas, classes, plans, and everything in between.";
  return <section className="dashboard">
    <div className="welcome-row">
      <div><p className="eyebrow">{view==="home"?"YOUR WORKSPACE":"NOTES"}</p><h1>{title}</h1><p className="muted">{subtitle}</p></div>
      <button className="primary-btn desktop-create" onClick={onCreate}><Plus size={18}/> New note</button>
    </div>

    {view==="search" && query && <div className="search-info"><Search size={16}/> Showing results for <strong>“{query}”</strong></div>}

    {view==="home" && !query && !activeFolder && <section className="quick-grid">
      <QuickStat icon={<FileText/>} label="Total notes" value={notes.length}/>
      <QuickStat icon={<Clock3/>} label="Recently edited" value={notes.filter((n:any)=>Date.now()-n.updatedAt<604800000).length}/>
      <QuickStat icon={<Tag/>} label="Tags" value={tags.length}/>
    </section>}

    {notes.length===0 ? <EmptyState view={view} onCreate={onCreate}/> :
      <div className="note-grid">{notes.map((n:any)=><NoteCard key={n.id} note={n} folders={folders} onOpen={onOpen} onUpdate={onUpdate} onDelete={onDelete} onRestore={onRestore} onPermanentDelete={onPermanentDelete} onExport={onExport}/>)}</div>}
  </section>;
}

function QuickStat({icon,label,value}:{icon:React.ReactNode;label:string;value:number}) {
  return <div className="quick-stat"><div className="stat-icon">{icon}</div><div><strong>{value}</strong><span>{label}</span></div></div>;
}

function NoteCard({note,folders,onOpen,onUpdate,onDelete,onRestore,onPermanentDelete,onExport}:any) {
  const [menu,setMenu]=useState(false);
  const preview=stripHtml(note.content).replace(/\s+/g," ").trim();
  return <article className={`note-card color-${note.color}`} onClick={()=>onOpen(note.id)}>
    <div className="note-card-top"><span className="folder-label">{note.folderId ? folders.find((f:any)=>f.id===note.folderId)?.name : "Uncategorized"}</span>
      <div className="card-actions">
        {note.isPinned && <span className="pin-dot">●</span>}
        <button className="mini-btn" onClick={e=>{e.stopPropagation();setMenu(!menu)}}><Ellipsis size={17}/></button>
        {menu && <div className="card-menu" onClick={e=>e.stopPropagation()}>
          {!note.isTrashed && <button onClick={()=>{onUpdate(note.id,{isPinned:!note.isPinned});setMenu(false)}}>{note.isPinned?"Unpin":"Pin"}</button>}
          {!note.isTrashed && <button onClick={()=>{onUpdate(note.id,{isFavorite:!note.isFavorite});setMenu(false)}}>{note.isFavorite?"Unfavorite":"Favorite"}</button>}
          {!note.isTrashed && <button onClick={()=>{onUpdate(note.id,{isArchived:!note.isArchived});setMenu(false)}}>{note.isArchived?"Restore from archive":"Archive"}</button>}
          {note.isTrashed ? <><button onClick={()=>{onRestore(note.id);setMenu(false)}}>Restore</button><button className="danger" onClick={()=>{onPermanentDelete(note.id);setMenu(false)}}>Delete permanently</button></> :
          <button className="danger" onClick={()=>{onDelete(note.id);setMenu(false)}}>Move to trash</button>}
          {!note.isTrashed && <button onClick={()=>{onExport(note,"md");setMenu(false)}}>Export Markdown</button>}
        </div>}
      </div>
    </div>
    <h3>{note.title || "Untitled note"}</h3>
    <p>{preview || "Start writing something..."}</p>
    <div className="note-card-bottom"><div className="card-tags">{note.tags.slice(0,2).map((t:string)=><span key={t}>#{t}</span>)}</div><time>{fmtTime(note.updatedAt)}</time></div>
  </article>;
}

function EmptyState({view,onCreate}:{view:View;onCreate:()=>void}) {
  return <div className="empty"><div className="empty-icon">{view==="trash"?<Trash2/>:<FileText/>}</div><h2>{view==="trash"?"Trash is empty":"Nothing here yet"}</h2><p>{view==="search"?"Try another keyword.":"Capture your first idea and make it yours."}</p>{view!=="trash"&&<button className="primary-btn" onClick={onCreate}><Plus size={17}/> Create note</button>}</div>;
}

function Editor({note,folders,saving,update,onBack,onDelete,onExport,notify}:any) {
  const [title,setTitle]=useState(note.title);
  const [tagInput,setTagInput]=useState("");
  const editor=useEditor({
    extensions:[
      StarterKit.configure({heading:{levels:[1,2,3]},bulletList:{},orderedList:{},blockquote:{},codeBlock:{}}),
      UnderlineExtension, Highlight, Link.configure({openOnClick:false}), TextAlign.configure({types:["heading","paragraph"]}),
      Placeholder.configure({placeholder:"Start writing your thoughts, notes, plans…"})
    ],
    content:note.content,
    onUpdate:({editor})=>update(note.id,{content:editor.getHTML()})
  });

  useEffect(()=>{ if(editor && note.content!==editor.getHTML() && !editor.isFocused) editor.commands.setContent(note.content || "",false)},[note.id]);
  useEffect(()=>setTitle(note.title),[note.id]);

  const addTag=()=>{const t=tagInput.trim().replace(/^#/,"").toLowerCase();if(t){update(note.id,{tags:Array.from(new Set([...note.tags,t]))});setTagInput("")}};
  return <section className="editor-page">
    <div className="editor-top">
      <button className="back-btn" onClick={onBack}><ChevronLeft size={19}/> Back</button>
      <div className="save-status">{saving?"Saving…":"Saved ✓"}</div>
      <div className="editor-actions">
        <button className={`icon-btn ${note.isFavorite?"favorite-active":""}`} onClick={()=>update(note.id,{isFavorite:!note.isFavorite})}><Heart size={18}/></button>
        <button className={`icon-btn ${note.isPinned?"pinned-active":""}`} onClick={()=>update(note.id,{isPinned:!note.isPinned})}><Star size={18}/></button>
        <button className="icon-btn" onClick={()=>onExport(note,"md")}><Download size={18}/></button>
        <button className="icon-btn danger-icon" onClick={onDelete}><Trash2 size={18}/></button>
      </div>
    </div>
    <div className="editor-meta">
      <select value={note.folderId||""} onChange={e=>update(note.id,{folderId:e.target.value||null})}>
        <option value="">Uncategorized</option>{folders.map((f:FolderType)=><option key={f.id} value={f.id}>{f.name}</option>)}
      </select>
      <div className="tags-editor">{note.tags.map((t:string)=><span key={t} className="tag-pill">#{t}<button onClick={()=>update(note.id,{tags:note.tags.filter(x=>x!==t)})}>×</button></span>)}<input value={tagInput} onChange={e=>setTagInput(e.target.value)} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();addTag()}}} placeholder="+ tag"/></div>
    </div>
    <input className="note-title-input" value={title} onChange={e=>{setTitle(e.target.value);update(note.id,{title:e.target.value})}} placeholder="Untitled note" />
    <Toolbar editor={editor}/>
    <div className="editor-body" style={{fontSize:noteFontSize(note)}}><EditorContent editor={editor}/></div>
    <div className="editor-footer"><span>Updated {fmtTime(note.updatedAt)}</span><button className="ai-button" onClick={()=>notify("AI integration is ready for your API key.")}><Sparkles size={16}/> AI tools</button></div>
  </section>;
}
function noteFontSize(note:Note){return undefined}

function SettingsView({settings,setSettings,notes,onImport}:any) {
  const exportAll=()=>{
    const blob=new Blob([JSON.stringify(notes,null,2)],{type:"application/json"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="noteflow-backup.json";a.click();URL.revokeObjectURL(a.href);
  };
  const importFile=(e:React.ChangeEvent<HTMLInputElement>)=>{
    const file=e.target.files?.[0];if(!file)return;
    const reader=new FileReader();reader.onload=()=>{try{const data=JSON.parse(String(reader.result));const arr=Array.isArray(data)?data:(data.notes||[]);if(!Array.isArray(arr))throw new Error();onImport(arr);alert(`Imported ${arr.length} notes.`)}catch{alert("That file is not a valid NoteFlow JSON backup.")}};reader.readAsText(file);
  };
  return <section className="settings-page"><p className="eyebrow">PREFERENCES</p><h1>Settings</h1>
    <SettingGroup title="Appearance"><SettingRow label="Theme" desc="Choose how NoteFlow looks."><div className="segmented">{(["light","dark","system"] as const).map(x=><button key={x} className={settings.theme===x?"active":""} onClick={()=>setSettings({...settings,theme:x})}>{x[0].toUpperCase()+x.slice(1)}</button>)}</div></SettingRow></SettingGroup>
    <SettingGroup title="Editor"><SettingRow label="Font size" desc="Adjust comfortable reading and writing size."><div className="segmented">{(["small","medium","large"] as const).map(x=><button key={x} className={settings.fontSize===x?"active":""} onClick={()=>setSettings({...settings,fontSize:x})}>{x}</button>)}</div></SettingRow><SettingRow label="Line spacing" desc="Control vertical breathing room."><div className="segmented">{(["compact","comfortable","relaxed"] as const).map(x=><button key={x} className={settings.lineSpacing===x?"active":""} onClick={()=>setSettings({...settings,lineSpacing:x})}>{x}</button>)}</div></SettingRow><SettingRow label="Autosave" desc="Save changes automatically while you write."><Toggle value={settings.autosave} onChange={v=>setSettings({...settings,autosave:v})}/></SettingRow></SettingGroup>
    <SettingGroup title="Your data"><SettingRow label="Export backup" desc="Download all notes as a JSON backup."><button className="secondary-btn" onClick={exportAll}><FileDown size={16}/> Export</button></SettingRow><SettingRow label="Import backup" desc="Add notes from a NoteFlow JSON backup."><label className="secondary-btn"><Upload size={16}/> Import<input type="file" accept=".json,application/json" hidden onChange={importFile}/></label></SettingRow></SettingGroup>
    <SettingGroup title="About"><SettingRow label="NoteFlow" desc="Version 1.0.0 · Local-first notes."><CircleHelp size={19}/></SettingRow><p className="privacy-note">Your notes are stored in this browser on this device. This version does not upload your notes to a server.</p></SettingGroup>
  </section>;
}
function SettingGroup({title,children}:{title:string;children:React.ReactNode}){return <div className="setting-group"><h2>{title}</h2>{children}</div>}
function SettingRow({label,desc,children}:{label:string;desc:string;children:React.ReactNode}){return <div className="setting-row"><div><strong>{label}</strong><p>{desc}</p></div><div>{children}</div></div>}
function Toggle({value,onChange}:{value:boolean;onChange:(v:boolean)=>void}){return <button className={`toggle ${value?"on":""}`} onClick={()=>onChange(!value)}><span/></button>}

function Modal({title,onClose,children}:{title:string;onClose:()=>void;children:React.ReactNode}){return <div className="modal-backdrop" onMouseDown={onClose}><div className="modal" onMouseDown={e=>e.stopPropagation()}><div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><X size={18}/></button></div>{children}</div></div>}
function FolderForm({onCreate}:{onCreate:(x:string)=>void}){const [v,setV]=useState("");return <form onSubmit={e=>{e.preventDefault();if(v.trim())onCreate(v.trim())}}><input autoFocus className="modal-input" value={v} onChange={e=>setV(e.target.value)} placeholder="e.g. Exam prep"/><button className="primary-btn full" type="submit">Create folder</button></form>}
function TagForm({notes,onCreate}:{notes:Note[];onCreate:(x:string)=>void}){const [v,setV]=useState("");return <form onSubmit={e=>{e.preventDefault();if(v.trim())onCreate(v.trim().replace(/^#/,"").toLowerCase())}}><input autoFocus className="modal-input" value={v} onChange={e=>setV(e.target.value)} placeholder="e.g. physics"/><p className="muted small">Tags are lowercase and can be added to notes from the editor.</p><button className="primary-btn full" type="submit">Add tag</button></form>}

function Onboarding({onDone}:{onDone:()=>void}) {
  const [step,setStep]=useState(0);
  const slides=[["Your ideas. Organized.","A fast, calm space for notes, schoolwork, plans, and ideas."],["Write anything, anytime.","Start typing in seconds. Your notes stay saved on this device."],["Find everything instantly.","Folders, tags, favorites, search, and a clean distraction-free editor."]];
  return <div className="onboarding"><div className="onboard-card"><div className="onboard-logo"><div className="brand-mark"><Zap size={20}/></div><span>NoteFlow</span></div><div className="onboard-art"><div className="floating-card c1"><FileText size={18}/><span>Science notes</span></div><div className="floating-card c2"><Check size={18}/><span>Homework ✓</span></div><div className="hero-icon"><Zap size={34}/></div></div><div className="dots">{slides.map((_,i)=><span key={i} className={i===step?"active":""}/>)}</div><h1>{slides[step][0]}</h1><p>{slides[step][1]}</p><button className="primary-btn full" onClick={()=>step<2?setStep(step+1):onDone()}>{step<2?"Continue":"Get started"}<ChevronRight size={18}/></button><button className="skip" onClick={onDone}>Skip</button></div></div>;
}

export default App;